import numpy as np
def make_transaction_features(df):
    out=df.copy()
    out["amount_log"]=np.log1p(out["amount"])
    out["amount_to_balance"]=out["amount"]/(out["account_balance"]+1)
    out["velocity_score"]=out["transactions_24h"]/(out["account_age_days"]+1)
    out["night_flag"]=((out["hour"]<6)|(out["hour"]>=23)).astype(int)
    out["international_risk"]=((out["international"]==1)&(out["device_trust"]<.4)).astype(int)
    out["high_velocity"]=(out["transactions_24h"]>=8).astype(int)
    return out
