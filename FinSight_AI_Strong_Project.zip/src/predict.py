import joblib,pandas as pd
from .utils import make_transaction_features
def score_transaction(payload):
    df=pd.DataFrame([payload]); m=joblib.load("models/fraud_model.joblib"); r=joblib.load("models/credit_risk_model.joblib")
    fp=float(m.predict_proba(make_transaction_features(df))[:,1][0])
    rf=["credit_score","account_balance","transactions_24h","account_age_days","failed_logins","chargebacks","merchant_risk"]
    rp=float(r.predict_proba(df[rf])[:,1][0])
    return {"fraud_probability":round(fp,4),"credit_risk_probability":round(rp,4),"overall_risk_score":round((.7*fp+.3*rp)*100,2),"decision":"REVIEW" if fp>=.45 else "APPROVE"}
