from flask import Flask,request,jsonify
from src.predict import score_transaction
app=Flask(__name__)
@app.get("/health")
def health(): return {"status":"ok","service":"FinSight AI"}
@app.post("/predict")
def predict(): return jsonify(score_transaction(request.get_json(force=True)))
if __name__=="__main__": app.run(host="0.0.0.0",port=5000,debug=True)
