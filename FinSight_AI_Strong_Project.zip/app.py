import json
import streamlit as st,pandas as pd,plotly.express as px
from src.predict import score_transaction
st.set_page_config(page_title="FinSight AI",page_icon="💳",layout="wide")
st.title("💳 FinSight AI")
st.caption("Intelligent Financial Risk & Fraud Detection Platform")
df=pd.read_csv("data/transactions.csv")
m=json.load(open("reports/metrics.json"))
a,b,c,d=st.columns(4); a.metric("Transactions",f"{len(df):,}"); b.metric("Fraud Rate",f"{df.fraud.mean()*100:.2f}%"); c.metric("ROC-AUC",f"{m['roc_auc']:.3f}"); d.metric("PR-AUC",f"{m['pr_auc']:.3f}")
st.plotly_chart(px.histogram(df,x="amount",color="fraud",nbins=60,title="Transaction Amount Distribution"),use_container_width=True)
st.plotly_chart(px.line(df.groupby("hour",as_index=False).fraud.mean(),x="hour",y="fraud",markers=True,title="Fraud Rate by Hour"),use_container_width=True)
st.subheader("Real-Time Transaction Scoring")
fields=["amount","account_balance","transactions_24h","account_age_days","device_trust","international","hour","merchant_risk","failed_logins","chargebacks","distance_from_home_km","credit_score"]
defaults=[250,50000,3,800,.8,0,14,.2,0,0,10,720]
vals={}
cols=st.columns(3)
for i,(f,v) in enumerate(zip(fields,defaults)): vals[f]=cols[i%3].number_input(f,value=float(v))
if st.button("Run FinSight Risk Engine",type="primary"):
    for f in ["transactions_24h","account_age_days","international","hour","failed_logins","chargebacks"]: vals[f]=int(vals[f])
    st.json(score_transaction(vals))
