# FinSight AI — Intelligent Financial Risk & Fraud Detection Platform

A portfolio-grade end-to-end ML project for financial fraud detection and credit-risk analytics.

## Highlights
- 30,000 synthetic banking transactions
- Random Forest fraud classifier
- Gradient Boosting credit-risk model
- Feature engineering and risk scoring
- ROC-AUC: 0.527
- PR-AUC: 0.096
- Interactive Streamlit dashboard
- Flask REST API
- Saved production-style model artifacts
- Business-oriented risk decision: APPROVE / REVIEW

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```
API:
```bash
python api.py
```

## Portfolio positioning
This demonstrates machine learning, financial analytics, model evaluation, deployment, dashboarding and business decision support.

**Disclaimer:** synthetic data only; not for real financial decisions.
